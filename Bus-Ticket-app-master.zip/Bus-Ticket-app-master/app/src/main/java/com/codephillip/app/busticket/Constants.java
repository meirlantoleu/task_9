package com.codephillip.app.busticket;

/**
 * Created by codephillip on 19/10/17.
 */

public class Constants {
    public static final String HAS_BOOKED = "has_booked";

}
