# Bus-Ticket-app
Android app that allows users to book bus tickets

Libraries

Content provider generator
https://github.com/BoD/android-contentprovider-generator

POJO site
Get the json response from server and create POJO files
http://www.jsonschema2pojo.org/
